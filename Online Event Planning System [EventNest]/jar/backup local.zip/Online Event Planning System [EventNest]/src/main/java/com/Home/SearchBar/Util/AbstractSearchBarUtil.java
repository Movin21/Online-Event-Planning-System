package com.Home.SearchBar.Util;

import java.util.ArrayList;

import com.Admin.AdminPortalContent.Event.Model.Event;

abstract public class AbstractSearchBarUtil {
	public abstract ArrayList<Event> getSearchResult();
}
